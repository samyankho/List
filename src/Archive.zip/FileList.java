import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class FileList<E> extends FileContainer implements List<E>{

	public List<E> list;
	public RandomAccessFile raf;
		
	public FileList(String name) {
		list = new ArrayList<E>();
		fileName = name;
		try {
			raf = new RandomAccessFile(fileName, "rw");
			getListFromFile();
			raf.setLength(0);
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public FileList() {
		list = new ArrayList<E>();
		fileName = String.valueOf(System.currentTimeMillis());
		try {
			raf = new RandomAccessFile(fileName, "rw");
			getListFromFile();
			raf.setLength(0);
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void getListFromFile() {
		
	}
	
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public void add(int index, E element) {
		list.add(index, element);
	}

	@Override
	public E remove(int index) {
		return list.remove(index);
	}
	
	@Override
	public void clear() {
//	    list.addAll(null);
		list.clear();
	}
	
	@Override
	public boolean add(E e) {
		// TODO Auto-generated method stub
//		return list.add(e);
		String str = e.toString();
		String a = null;
		for(int i=0;i < str.length();i++) {
			int num = Character.getNumericValue(str.charAt(i));
			if(num>= 1 && num <= 9 && (str.charAt(i-1) != '-' && i!=0)) {
				a = a+Integer.toString(num);
			}
//			else if() {
//				
//			}
		}
		if(a.isEmpty()) {
			return false;
		}
		else {
			list.add((E) a);
			return true;
		}
//		if(str.matches(".*\\d+.*")) {
//			return true;
//		}
//		else {
//			return false;
//		}

	}

	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
//		return list.indexOf(o) >= 0;
		if (list.contains(o)) {
			list.remove(o);
			return true;
		} else {
			return false;
		}
	}


	
	@Override
	public boolean isEmpty() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean contains(Object o) {
		throw new UnsupportedOperationException();
	}

	@Override
	public Iterator<E> iterator() {
		throw new UnsupportedOperationException();
	}

	@Override
	public Object[] toArray() {
		throw new UnsupportedOperationException();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		throw new UnsupportedOperationException();
	}


	@Override
	public boolean containsAll(Collection<?> c) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean addAll(int index, Collection<? extends E> c) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		throw new UnsupportedOperationException();
	}



	@Override
	public E get(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public E set(int index, E element) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int indexOf(Object o) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int lastIndexOf(Object o) {
		throw new UnsupportedOperationException();
	}

	@Override
	public ListIterator<E> listIterator() {
		throw new UnsupportedOperationException();
	}

	@Override
	public ListIterator<E> listIterator(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<E> subList(int fromIndex, int toIndex) {
		throw new UnsupportedOperationException();
	}

	@Override
	public String getFileName() {
//		throw new UnsupportedOperationException();
		return fileName;
	}

	@Override
	public long getFileSize() {
		return list.size();
	}

}
