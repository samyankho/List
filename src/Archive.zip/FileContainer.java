
public abstract class FileContainer {
		protected String fileName;
		public abstract String getFileName();
		public abstract long getFileSize();
	}

